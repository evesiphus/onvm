DAG service chain

Configuration:

![DAG structure](assets/dag.png-1.png)
